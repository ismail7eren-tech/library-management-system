from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    db = get_db()
    c = db.cursor()
    # Kitaplar Tablosu
    c.execute("""CREATE TABLE IF NOT EXISTS kitaplar (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        ad TEXT, yazar TEXT, durum TEXT)""")
    
    # Üyeler Tablosu (TC ve Telefon Eklendi)
    c.execute("""CREATE TABLE IF NOT EXISTS uyeler (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        ad TEXT, tc TEXT, telefon TEXT)""")
    
    # Ödünç Tablosu
    c.execute("""CREATE TABLE IF NOT EXISTS oduncler (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        kitap_id INTEGER, uye_id INTEGER, 
        tarih DATETIME DEFAULT CURRENT_TIMESTAMP)""")
    db.commit()
    db.close()

create_tables()

@app.route("/")
def home():
    db = get_db()
    kitaplar = db.execute("SELECT * FROM kitaplar").fetchall()
    uyeler = db.execute("SELECT * FROM uyeler").fetchall()
    oduncler = db.execute("""
        SELECT o.id, k.ad as kitap_ad, u.ad as uye_ad 
        FROM oduncler o 
        JOIN kitaplar k ON o.kitap_id = k.id 
        JOIN uyeler u ON o.uye_id = u.id
    """).fetchall()

    stats = {
        'kitap_sayisi': len(kitaplar),
        'uye_sayisi': len(uyeler),
        'odunc_sayisi': len(oduncler)
    }
    db.close()
    return render_template("index.html", kitaplar=kitaplar, uyeler=uyeler, oduncler=oduncler, stats=stats)

@app.route("/kitap_ekle", methods=["POST"])
def kitap_ekle():
    db = get_db()
    db.execute("INSERT INTO kitaplar (ad, yazar, durum) VALUES (?,?,?)",
              (request.form["ad"], request.form["yazar"], "Mevcut"))
    db.commit()
    db.close()
    return redirect("/")

@app.route("/uye_ekle", methods=["POST"])
def uye_ekle():
    db = get_db()
    db.execute("INSERT INTO uyeler (ad, tc, telefon) VALUES (?,?,?)", 
              (request.form["ad"], request.form["tc"], request.form["telefon"]))
    db.commit()
    db.close()
    return redirect("/")

@app.route("/odunc_al", methods=["POST"])
def odunc_al():
    kitap_id = request.form.get("kitap")
    uye_id = request.form.get("uye")
    if kitap_id and uye_id:
        db = get_db()
        db.execute("UPDATE kitaplar SET durum='Ödünç' WHERE id=?", (kitap_id,))
        db.execute("INSERT INTO oduncler (kitap_id, uye_id) VALUES (?,?)", (kitap_id, uye_id))
        db.commit()
        db.close()
    return redirect("/")

@app.route("/iade/<int:id>")
def iade(id):
    db = get_db()
    odunc = db.execute("SELECT kitap_id FROM oduncler WHERE id=?", (id,)).fetchone()
    if odunc:
        db.execute("UPDATE kitaplar SET durum='Mevcut' WHERE id=?", (odunc['kitap_id'],))
        db.execute("DELETE FROM oduncler WHERE id=?", (id,))
        db.commit()
    db.close()
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)